const express = require('express');
const Order = require('../models/Order');
const { verifyToken, adminOnly } = require('../middleware/auth');
const router = express.Router();

router.post('/', verifyToken, async (req, res) => {
  const { products, total } = req.body;
  const order = new Order({ userId: req.user.id, products, total });
  await order.save();
  res.status(201).json(order);
});

router.get('/', verifyToken, async (req, res) => {
  const orders = await Order.find({ userId: req.user.id });
  res.json(orders);
});

router.get('/admin', verifyToken, adminOnly, async (req, res) => {
  const orders = await Order.find();
  res.json(orders);
});

module.exports = router;
