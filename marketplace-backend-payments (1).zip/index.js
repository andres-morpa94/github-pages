const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI;

mongoose.connect(MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// Rutas básicas
app.get('/', (req, res) => {
  res.send('API de Marketplace funcionando');
});

const productRoutes = require('./routes/products');
app.use('/api/products', productRoutes);
const userRoutes = require('./routes/users');
const cartRoutes = require('./routes/cart');
const orderRoutes = require('./routes/orders');

app.use('/api/users', userRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/orders', orderRoutes);
const stripeRoutes = require('./routes/payStripe');
const paypalRoutes = require('./routes/payPayPal');

app.use('/api/pay', stripeRoutes);
app.use('/api/pay', paypalRoutes);



app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
