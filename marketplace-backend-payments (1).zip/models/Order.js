const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  userId: String,
  products: [{
    productId: String,
    quantity: Number
  }],
  total: Number,
  status: { type: String, default: 'Pendiente' }
}, { timestamps: true });

module.exports = mongoose.model('Order', orderSchema);
