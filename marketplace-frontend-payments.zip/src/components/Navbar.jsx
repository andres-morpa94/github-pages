import { Link } from 'react-router-dom'

const Navbar = () => {
  return (
    <nav className="flex items-center justify-between p-4 bg-white shadow-md">
      <Link to="/" className="text-xl font-bold">MiTienda</Link>
      <div className="space-x-4">
        <Link to="/">Inicio</Link>
        <Link to="/cart">Carrito</Link>
      </div>
    </nav>
  )
}

export default Navbar
