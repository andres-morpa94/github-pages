import { useEffect, useState } from 'react'

const Cart = () => {
  const [cart, setCart] = useState({ items: [] })

  useEffect(() => {
    const fetchCart = async () => {
      const res = await fetch('http://localhost:5000/api/cart', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      })
      const data = await res.json()
      setCart(data)
    }
    fetchCart()
  }, [])

  const total = cart.items.reduce((sum, item) => sum + item.quantity * 100, 0)

  const handleOrder = async () => {
    await fetch('http://localhost:5000/api/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({ products: cart.items, total })
    })
    alert('Pedido realizado')
  }

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">Carrito</h2>
      <ul>
        {cart.items.map((item, idx) => (
          <li key={idx}>Producto: {item.productId}, Cantidad: {item.quantity}</li>
        ))}
      </ul>
      <p className="font-semibold mt-2">Total: ${total}</p>
      <button onClick={handleOrder} className="mt-2 bg-green-500 text-white px-4 py-2 rounded">
        Realizar pedido
      </button>
    </div>
  )
}

export default Cart
