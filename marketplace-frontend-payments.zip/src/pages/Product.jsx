import { useParams } from 'react-router-dom'

const Product = () => {
  const { id } = useParams()
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Producto #{id}</h1>
      <p>Descripción del producto...</p>
    </div>
  )
}

export default Product
