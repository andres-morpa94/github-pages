import { useEffect, useState } from 'react'

const AdminOrders = () => {
  const [orders, setOrders] = useState([])

  useEffect(() => {
    const fetchOrders = async () => {
      const res = await fetch('http://localhost:5000/api/orders/admin', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      })
      const data = await res.json()
      setOrders(data)
    }
    fetchOrders()
  }, [])

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">Pedidos (Admin)</h2>
      <ul className="space-y-2">
        {orders.map((order, idx) => (
          <li key={idx} className="border p-2 rounded">
            <p>ID: {order._id}</p>
            <p>Total: ${order.total}</p>
            <p>Estado: {order.status}</p>
          </li>
        ))}
      </ul>
    </div>
  )
}

export default AdminOrders
