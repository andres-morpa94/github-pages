import { Link } from 'react-router-dom'

const products = [
  { id: 1, name: 'Laptop', price: 999, image: 'https://via.placeholder.com/150' },
  { id: 2, name: 'Camisa', price: 29, image: 'https://via.placeholder.com/150' },
]

const Home = () => {
  return (
    <div className="p-4 grid grid-cols-2 md:grid-cols-4 gap-4">
      {products.map(product => (
        <Link key={product.id} to={`/product/${product.id}`} className="border rounded-lg p-2 shadow hover:shadow-lg">
          <img src={product.image} alt={product.name} />
          <h3 className="font-semibold">{product.name}</h3>
          <p>${product.price}</p>
        </Link>
      ))}
    </div>
  )
}

export default Home
