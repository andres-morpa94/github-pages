import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import Product from './pages/Product'
import Cart from './pages/Cart'
import Navbar from './components/Navbar'
import Login from './pages/Login'
import UserOrders from './pages/UserOrders'
import AdminOrders from './pages/AdminOrders'
import Checkout from './pages/Checkout'

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/product/:id" element={<Product />} />
        <Route path="/cart" element={<Cart />} />
      <Route path="/login" element={<Login />} />
        <Route path="/orders" element={<UserOrders />} />
        <Route path="/admin/orders" element={<AdminOrders />} />
        <Route path="/checkout" element={<Checkout />} />
</Routes>
    </Router>
  )
}

export default App
